# Wp Gov Brasil
=====================

Tema inicial em Wordpress com os padrões da SECOM do Governo Federal

## Em construção....


## Páginas personalizadas
Para construir páginas personalizadas(home e internas) utilize o plugin Site origin Panels(https://wordpress.org/plugins/siteorigin-panels/)
Basta criar novas widgets para cada área 
