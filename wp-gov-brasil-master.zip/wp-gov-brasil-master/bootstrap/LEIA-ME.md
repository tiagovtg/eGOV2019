Versão do bootstrap customizada, com download realizado em: http://getbootstrap.com/2.3.2/customize.html
Alterações com motivo de adequação à 960 pixels de largura máxima.

Alterações:
---------------------------------------------------
Base CSS > Icons - RETIRADO
Miscellaneous > Wells - RETIRADO
Responsive > Large desktops (>1200px) - RETIRADO
Grid System > @gridColumnWidth - 60x para 50px
Grid System > @gridGutterWidth - 20px para 30px


Wordpress
---------------------------------------------------
Atualizei a versão do Bootstrap para 3.3.4
Alterações Bootstrap - Customizer
---------------------------------------------------
# Removidos
 ## Common CSS
	-Typography
	- Code
	- Buttons

 ## Components
	- Glyphicons
	- Button groups
	- Input groups
	- Navs
	- Navbar
	- Breadcrumbs
	- Pagination
	- Pager
	- Labels
	- Badges
	- Jumbotron
	- Thumbnails
	- Alerts
	- Progress bars
	- Media items
	- List groups
	- Panels
	- Wells
	- Close icon
	
 ## JavaScript components
	- Tooltips
	- Popovers

 ## jQuery plugins
	### Linked to components
	 - Alert dismissal
	 - Advanced buttons
	 - Tooltips
	 - Popovers (requires Tooltips)
	 - Togglable tabs
	
Media queries breakpoints
@screen-md > 960px;
@screen-lg > 960px;

Container sizes > 
@container-desktop - (930px + @grid-gutter-width)
@container-large-desktop - 960px

